// Global variables
let currentQuestionIndex = 0;
let questions = [];
let answers = {};
let resultsPage = '';

// Navigation function
function navigateTo(page) {
    window.location.href = page;
}

// Initialize questions for question pages
function initializeQuestions(questionData, resultPage) {
    questions = questionData;
    resultsPage = resultPage;
    currentQuestionIndex = 0;
    answers = {};
    
    displayQuestion();
    updateProgress();
}

// Display current question
function displayQuestion() {
    const question = questions[currentQuestionIndex];
    const questionText = document.getElementById('question-text');
    const optionsContainer = document.getElementById('options-container');
    const currentQuestionSpan = document.getElementById('current-question');
    
    if (questionText) questionText.textContent = question.question;
    if (currentQuestionSpan) currentQuestionSpan.textContent = currentQuestionIndex + 1;
    
    if (optionsContainer) {
        optionsContainer.innerHTML = '';
        
        question.options.forEach(option => {
            const optionDiv = document.createElement('div');
            optionDiv.className = 'option-item';
            optionDiv.onclick = () => selectOption(option.value, optionDiv);
            
            optionDiv.innerHTML = `
                <input type="radio" name="question" value="${option.value}" id="${option.value}">
                <label for="${option.value}">${option.label}</label>
            `;
            
            optionsContainer.appendChild(optionDiv);
        });
    }
    
    updateNavigationButtons();
}

// Select option
function selectOption(value, element) {
    // Remove previous selection
    document.querySelectorAll('.option-item').forEach(item => {
        item.classList.remove('selected');
    });
    
    // Add selection to current item
    element.classList.add('selected');
    element.querySelector('input').checked = true;
    
    // Store answer
    answers[questions[currentQuestionIndex].id] = value;
    
    updateNavigationButtons();
}

// Update navigation buttons
function updateNavigationButtons() {
    const prevBtn = document.getElementById('prev-btn');
    const nextBtn = document.getElementById('next-btn');
    
    if (prevBtn) {
        prevBtn.disabled = currentQuestionIndex === 0;
    }
    
    if (nextBtn) {
        const hasAnswer = answers[questions[currentQuestionIndex].id];
        nextBtn.disabled = !hasAnswer;
        
        if (currentQuestionIndex === questions.length - 1) {
            nextBtn.innerHTML = 'Get Recommendations <i class="fas fa-arrow-right"></i>';
        } else {
            nextBtn.innerHTML = 'Next <i class="fas fa-arrow-right"></i>';
        }
    }
}

// Previous question
function previousQuestion() {
    if (currentQuestionIndex > 0) {
        currentQuestionIndex--;
        displayQuestion();
        updateProgress();
    }
}

// Next question
function nextQuestion() {
    if (currentQuestionIndex < questions.length - 1) {
        currentQuestionIndex++;
        displayQuestion();
        updateProgress();
    } else {
        // Store answers in localStorage and navigate to results
        localStorage.setItem('quizAnswers', JSON.stringify(answers));
        navigateTo(resultsPage);
    }
}

// Update progress bar
function updateProgress() {
    const progressFill = document.getElementById('progress-fill');
    if (progressFill) {
        const progress = ((currentQuestionIndex + 1) / questions.length) * 100;
        progressFill.style.width = progress + '%';
    }
}

// Generate book results
function generateBookResults(recommendations) {
    const answers = JSON.parse(localStorage.getItem('quizAnswers') || '{}');
    const mood = answers[1] || 'default';
    const genre = answers[2] || 'default';
    
    let selectedRecommendations = recommendations.default;
    
    if (mood === 'happy' && genre === 'fiction') {
        selectedRecommendations = recommendations.happy_fiction;
    } else if (mood === 'sad' && genre === 'fiction') {
        selectedRecommendations = recommendations.sad_fiction;
    } else if (genre === 'mystery') {
        selectedRecommendations = recommendations.mystery;
    }
    
    displayBookRecommendations(selectedRecommendations);
}

// Display book recommendations
function displayBookRecommendations(recommendations) {
    const container = document.getElementById('results-container');
    if (!container) return;
    
    container.innerHTML = '';
    
    recommendations.forEach(book => {
        const card = document.createElement('div');
        card.className = 'recommendation-card';
        
        card.innerHTML = `
            <div class="recommendation-header">
                <div class="recommendation-title">
                    <h3>${book.title}</h3>
                    <p class="recommendation-subtitle">by ${book.author}</p>
                </div>
                <div class="recommendation-meta">
                    <span class="genre-badge">${book.genre}</span>
                </div>
            </div>
            <p class="recommendation-description">${book.description}</p>
            <div class="recommendation-links">
                <a href="${book.amazonLink}" target="_blank" class="link-btn primary">
                    <i class="fas fa-external-link-alt"></i> Buy on Amazon
                </a>
                <a href="${book.goodreadsLink}" target="_blank" class="link-btn secondary">
                    <i class="fas fa-external-link-alt"></i> View on Goodreads
                </a>
            </div>
        `;
        
        container.appendChild(card);
    });
}

// Generate music results
function generateMusicResults(recommendations) {
    const answers = JSON.parse(localStorage.getItem('quizAnswers') || '{}');
    const energy = answers[1] || 'default';
    const genre = answers[2] || 'default';
    const context = answers[4] || 'default';
    
    let selectedRecommendations = recommendations.default;
    
    if (energy === 'high' && genre === 'pop') {
        selectedRecommendations = recommendations.high_pop;
    } else if (energy === 'low' && genre === 'indie') {
        selectedRecommendations = recommendations.low_indie;
    } else if (context === 'workout') {
        selectedRecommendations = recommendations.workout;
    }
    
    displayMusicRecommendations(selectedRecommendations);
}

// Display music recommendations
function displayMusicRecommendations(recommendations) {
    const container = document.getElementById('results-container');
    if (!container) return;
    
    container.innerHTML = '';
    
    recommendations.forEach(song => {
        const card = document.createElement('div');
        card.className = 'recommendation-card';
        
        card.innerHTML = `
            <div class="recommendation-header">
                <div class="recommendation-title">
                    <h3>${song.title}</h3>
                    <p class="recommendation-subtitle">by ${song.artist}</p>
                </div>
                <div class="recommendation-meta">
                    <span class="genre-badge">${song.genre}</span>
                </div>
            </div>
            <p class="recommendation-description">${song.description}</p>
            <div class="recommendation-links">
                <a href="${song.spotifyLink}" target="_blank" class="link-btn primary">
                    <i class="fas fa-play"></i> Play on Spotify
                </a>
                <a href="${song.youtubeLink}" target="_blank" class="link-btn secondary">
                    <i class="fas fa-external-link-alt"></i> Watch on YouTube
                </a>
            </div>
        `;
        
        container.appendChild(card);
    });
}

// Generate movie results
function generateMovieResults(recommendations) {
    const answers = JSON.parse(localStorage.getItem('quizAnswers') || '{}');
    const mood = answers[1] || 'default';
    const genre = answers[2] || 'default';
    
    let selectedRecommendations = recommendations.default;
    
    if (mood === 'adventurous' && genre === 'action') {
        selectedRecommendations = recommendations.adventurous_action;
    } else if (mood === 'fun' && genre === 'comedy') {
        selectedRecommendations = recommendations.fun_comedy;
    } else if (mood === 'scared' && genre === 'horror') {
        selectedRecommendations = recommendations.scared_horror;
    }
    
    displayMovieRecommendations(selectedRecommendations);
}

// Display movie recommendations
function displayMovieRecommendations(recommendations) {
    const container = document.getElementById('results-container');
    if (!container) return;
    
    container.innerHTML = '';
    
    recommendations.forEach(movie => {
        const card = document.createElement('div');
        card.className = 'recommendation-card';
        
        card.innerHTML = `
            <div class="recommendation-header">
                <div class="recommendation-title">
                    <h3>${movie.title} (${movie.year})</h3>
                    <p class="recommendation-subtitle">Directed by ${movie.director}</p>
                </div>
                <div class="recommendation-meta">
                    <span class="genre-badge">${movie.genre}</span>
                    <div class="rating">
                        <i class="fas fa-star"></i>
                        <span>${movie.rating}</span>
                    </div>
                </div>
            </div>
            <p class="recommendation-description">${movie.description}</p>
            <div class="recommendation-links">
                <a href="${movie.imdbLink}" target="_blank" class="link-btn primary">
                    <i class="fas fa-external-link-alt"></i> View on IMDb
                </a>
                <a href="${movie.netflixLink}" target="_blank" class="link-btn secondary">
                    <i class="fas fa-external-link-alt"></i> Watch on Netflix
                </a>
            </div>
        `;
        
        container.appendChild(card);
    });
}

// Initialize page based on current location
document.addEventListener('DOMContentLoaded', function() {
    // Add smooth scrolling and animations
    document.body.style.opacity = '0';
    setTimeout(() => {
        document.body.style.transition = 'opacity 0.5s ease';
        document.body.style.opacity = '1';
    }, 100);
    
    // Add click animations to cards
    document.querySelectorAll('.category-card, .recommendation-card').forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-5px)';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
        });
    });
});